import React from "react";
import Navbar from "./Navbar";
import {
  Typography,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Paper,
} from "@mui/material";
import { useLocation } from "react-router-dom";
import CommentCard from "./commentCard";
import "./videos.css";

export default function Details() {
  const { state } = useLocation();
  console.log(state);
  return (
    <div>
      <Navbar />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          marginTop: 30,
          marginBottom: 30,
        }}
      >
        <Typography variant="h3" sx={{ marginX: 4 }}>
          {state.title}
        </Typography>
      </div>
      <div>
        <Grid container component="main">
          <Grid
            item
            xs={12}
            sm={4}
            justifyItems="center"
            justifyContent="center"
          >
            <center>
              <Card
                sx={{
                  marginX: 3,
                  background:
                    "linear-gradient(135deg, rgb(6,13,42) 0%, rgb(51,69,167) 100%)",
                  color: "white",
                  border: 3,
                  borderColor: "#060D2A",
                }}
                elevation={6}
              >
                <CardHeader title="Like Count" />
                <CardContent>{state.stats.likes}</CardContent>
              </Card>
            </center>
          </Grid>
          <Grid item xs={12} sm={4}>
            <center>
              <Card
                sx={{
                  marginX: 3,
                  background:
                    "linear-gradient(135deg, rgb(6,13,42) 0%, rgb(51,69,167) 100%)",
                  color: "white",
                  border: 3,
                  borderColor: "#060D2A",
                }}
                elevation={6}
              >
                <CardHeader title="View Count" />
                <CardContent>{state.stats.views}</CardContent>
              </Card>
            </center>
          </Grid>
          <Grid
            item
            xs={12}
            sm={4}
            justifyItems="center"
            justifyContent="center"
          >
            <center>
              <Card
                sx={{
                  marginX: 3,
                  background:
                    "linear-gradient(135deg, rgb(6,13,42) 0%, rgb(51,69,167) 100%)",
                  color: "white",
                  border: 3,
                  borderColor: "#060D2A",
                }}
                elevation={6}
              >
                <CardHeader title="Comment Count" />
                <CardContent>{state.stats.comments}</CardContent>
              </Card>
            </center>
          </Grid>
        </Grid>
      </div>
      <div style={{ marginTop: "50px" }}>
        <Grid container component="main">
          <Grid
            item
            xs={12}
            sm={6}
            justifyItems="center"
            justifyContent="center"
          >
            <center>
              <Card
                sx={{
                  marginX: 3,
                  background: "#fff",
                  color: "white",
                  border: 3,
                  borderColor: "#060D2A",
                  height: "45vh",
                }}
                elevation={6}
              >
                <Grid sx={{ background: "#060D2A" }}>
                  <CardHeader title="Description" />
                </Grid>
                <CardContent>Hello</CardContent>
              </Card>
            </center>
          </Grid>
          <Grid
            item
            xs={12}
            sm={6}
            justifyItems="center"
            justifyContent="center"
          >
            <Card
              sx={{
                marginX: 3,
                background: "#fff",
                color: "white",
                border: 3,
                borderColor: "#060D2A",
                height: "45vh",
              }}
              elevation={6}
            >
              <Grid sx={{ background: "#060D2A" }}>
                <center>
                  <CardHeader title="Comments" />
                </center>
              </Grid>
              <CardContent className="comments">
                {state.comments.map((item, i) => (
                  <CommentCard key={i} value={item} />
                ))}
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </div>
    </div>
  );
}
