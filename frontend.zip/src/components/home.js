import { React, useState } from "react";
import background from "../background.jpg";
import "./home.css";
import { IconButton, InputBase, Paper } from "@mui/material";
import { Search } from "@mui/icons-material";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

export default function Home() {
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const handleSubmit = () => {
    console.log(url);
    var config = {
      headers: {
        "Content-Type": "text/plain",
        "Access-Control-Allow-Origin": "*",
      },
    };
    axios
      .get("http://127.0.0.1:5000/videos", { params: { url: url } }, config)
      .then((res) => {
        if (res.status === 200) {
          const state = {
            videos: res.data.videos,
            channel: res.data.channel
          }
          navigate("/videos", { state: state });
        } else {
          console.log("failed");
        }
      })
      .catch(() => {
        console.log("failed 2");
      });
  };
  return (
    <div
      style={{
        backgroundImage: `url(${background})`,
        width: "100vw",
        height: "100vh",
        backgroundSize: "100vw 100vh",
      }}
    >
      <div class="center">
        <Paper
          component="form"
          sx={{
            p: "2px 4px",
            display: "flex",
            alignItems: "center",
            width: "50vw",
            borderRadius: 50,
            border: 5,
            borderColor: "#757575",
          }}
        >
          <InputBase
            sx={{ ml: 1, width: "50vw", background: "white" }}
            placeholder="Enter the URL of your Youtube Channel"
            onSubmit={handleSubmit}
            onChange={(e) => setUrl(e.target.value)}
          />
          <IconButton
            sx={{ p: "10px" }}
            aria-label="search"
            onClick={handleSubmit}
          >
            <Search />
          </IconButton>
        </Paper>
      </div>
    </div>
  );
}
