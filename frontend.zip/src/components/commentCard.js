import {
  AccountCircleOutlined,
  TaskOutlined,
  Delete,
  Done,
  HomeOutlined,
  WorkOutlined,
} from "@mui/icons-material";
import {
  Avatar,
  Card,
  CardHeader,
  IconButton,
  Tooltip,
  Zoom,
  Typography,
} from "@mui/material";
import React from "react";

export default function CommentCard(props) {
  return (
    <div>
      <Tooltip arrow title={props.value} TransitionComponent={Zoom}>
        <Card sx={{ marginY: "5px" }}>
          <CardHeader
            avatar={<Avatar sx={{ backgroundColor: "#060D2A" }}>/</Avatar>}
            title={
              <Typography
                variant="body1"
                noWrap
                sx={{
                  maxWidth: "35vw",
                }}
              >
                {props.value}
              </Typography>
            }
            subheader="Positive"
          />
        </Card>
      </Tooltip>
    </div>
  );
}
